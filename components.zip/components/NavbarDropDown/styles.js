import styled from "styled-components";

export const NavbarDropDownWrapper = styled.div`
	padding: 5px;
`;
