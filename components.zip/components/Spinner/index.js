import React from "react";

function Spiner() {
	return <span className='spinner'></span>;
}

export default Spiner;
