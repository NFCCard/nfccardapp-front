1: Optimize Images
