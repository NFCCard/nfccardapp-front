// import deleteUserGalleryImage from "./deleteGalleryImage";

const deleteApi = {};
export default deleteApi;
