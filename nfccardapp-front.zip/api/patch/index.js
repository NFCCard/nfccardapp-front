import updateProfile from "./updateProfile";
const patch = { updateProfile };
export default patch;
