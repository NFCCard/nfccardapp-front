import getSingleProfile from "./getSingleProfile";
import getUserList from "./getUserList";

const get = { getSingleProfile, getUserList };
export default get;
