const icons = {
	instagram: "fab fa-instagram",
	telegram: "fab fa-telegram",
	whatsapp: "fab fa-whatsapp",
	dribble: "fab fa-dribbble",
	linkedin: "fab fa-linkedin",
	pinterest: "fab fa-pinterest",
	twitter: "fab fa-twitter",
	youtube: "fab fa-youtube",
	aparat: "",
	tiktok: "fab fa-tiktok",
	spotify: "fab fa-spotify",
	soundcloud: "fab fa-soundcloud",
	twitch: "fab fa-twitch",
};
export default icons;
