const BASE_URL = "https://api.wosite.ir/api/";

const config = {
	BASE_URL,
};
export default config;
