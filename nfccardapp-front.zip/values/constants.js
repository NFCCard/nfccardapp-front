const TOKEN = "TOKEN";
const INFO = "INFO";
const STORAGE = "_s";
const userTypes = ["user", "admin"];
const constants = {
	TOKEN,
	INFO,
	userTypes,
	STORAGE,
};
export default constants;
