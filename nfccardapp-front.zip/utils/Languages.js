export const languages = [
	{
		code: "en",
		name: "English",
		country_code: "gb",
	},
	{
		code: "fa",
		name: "فارسی",
		country_code: "ir",
		dir: "rtl",
	},
];
