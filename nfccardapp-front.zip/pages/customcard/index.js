import React from "react";

function CustomCard() {
	return (
		<main className='customCard'>
			<div className='card-boilerPlate'></div>
		</main>
	);
}

export default CustomCard;
